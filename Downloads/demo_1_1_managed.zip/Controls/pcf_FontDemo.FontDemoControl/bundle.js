/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "../Shared/font-loader.ts":
/*!********************************!*\
  !*** ../Shared/font-loader.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   loadFont: () => (/* binding */ loadFont)\n/* harmony export */ });\nfunction loadFont(config) {\n  switch (config.source) {\n    case \"google\":\n      injectGoogleFont(config.name, config.weights);\n      break;\n    case \"cdn\":\n      if (!config.cdnUrl) {\n        console.warn(\"Missing CDN URL for font: \".concat(config.name));\n        return;\n      }\n      injectCDNFont(config.name, config.cdnUrl, config.fontWeight);\n      break;\n    default:\n      console.warn(\"Unsupported font source: \".concat(config.source));\n  }\n}\nfunction injectGoogleFont(name, weights) {\n  var formattedName = name.replace(/ /g, \"+\");\n  var weightParam = (weights === null || weights === void 0 ? void 0 : weights.length) ? \":wght@\".concat(weights.join(\";\")) : \"\";\n  var href = \"https://fonts.googleapis.com/css2?family=\".concat(formattedName).concat(weightParam, \"&display=swap\");\n  injectStylesheet(href);\n}\nfunction injectCDNFont(name, cdnUrl) {\n  var fontWeight = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : \"normal\";\n  var fontFace = \"\\n    @font-face {\\n      font-family: '\".concat(name, \"';\\n      src: url('\").concat(cdnUrl, \"') format('woff2');\\n      font-weight: \").concat(fontWeight, \";\\n      font-style: normal;\\n    }\\n  \");\n  injectStyleBlock(fontFace);\n}\nfunction injectStylesheet(href) {\n  var link = document.createElement(\"link\");\n  link.rel = \"stylesheet\";\n  link.href = href;\n  document.head.appendChild(link);\n}\nfunction injectStyleBlock(css) {\n  var style = document.createElement(\"style\");\n  style.textContent = css;\n  document.head.appendChild(style);\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/../Shared/font-loader.ts?\n}");

/***/ }),

/***/ "./FontDemoControl/index.ts":
/*!**********************************!*\
  !*** ./FontDemoControl/index.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   FontDemoControl: () => (/* binding */ FontDemoControl)\n/* harmony export */ });\n/* harmony import */ var _Shared_font_loader__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../Shared/font-loader */ \"../Shared/font-loader.ts\");\n\nclass FontDemoControl {\n  init(context, notifyOutputChanged, state, container) {\n    this.container = container;\n    this.notifyOutputChanged = notifyOutputChanged;\n    // Initialize default state\n    this.state = {\n      fontFamily: \"\",\n      provider: \"Google\",\n      cdnUrl: \"\",\n      exampleText: \"The quick brown fox jumps over the lazy dog.\",\n      fontSize: 16,\n      fontWeight: \"normal\",\n      textAlign: \"left\",\n      textcolor: \"#000000\"\n    };\n    // Create input fields\n    var fontInput = this.createTextInput(\"Font name (e.g., Roboto)\", val => {\n      this.state.fontFamily = val;\n      this.validate(applyButton);\n    });\n    var providerSelect = this.createSelect([\"Google\", \"CDN\"], val => {\n      this.state.provider = val;\n      this.validate(applyButton);\n    });\n    var cdnInput = this.createTextInput(\"CDN URL (if using CDN)\", val => {\n      this.state.cdnUrl = val;\n      this.validate(applyButton);\n    });\n    var textInput = this.createTextInput(\"Example text\", val => {\n      this.state.exampleText = val;\n      this.renderFont();\n    });\n    var sizeInput = this.createNumberInput(\"Font size (e.g., 16)\", val => {\n      var parsed = parseInt(val, 10);\n      this.state.fontSize = isNaN(parsed) ? 16 : parsed;\n      this.validate(applyButton);\n    });\n    var weightInput = this.createTextInput(\"Font weight (e.g., normal, bold, 400)\", val => {\n      this.state.fontWeight = val;\n      this.validate(applyButton);\n    });\n    var alignInput = this.createSelect([\"left\", \"center\", \"right\"], val => {\n      this.state.textAlign = val;\n      this.validate(applyButton);\n    });\n    var textcolorInput = this.createTextInput(\"Text color (e.g., #000000 or red)\", val => {\n      this.state.textcolor = val;\n      this.validate(applyButton);\n    });\n    var applyButton = document.createElement(\"button\");\n    applyButton.textContent = \"Apply Font\";\n    applyButton.disabled = true;\n    applyButton.onclick = () => this.renderFont();\n    // Paragraph to display the rendered font\n    this.paragraph = document.createElement(\"p\");\n    this.paragraph.textContent = this.state.exampleText;\n    this.paragraph.style.marginTop = \"1rem\";\n    // Append inputs to container, each wrapped for vertical layout\n    this.container.appendChild(this.wrapField(fontInput));\n    this.container.appendChild(this.wrapField(providerSelect));\n    this.container.appendChild(this.wrapField(cdnInput));\n    this.container.appendChild(this.wrapField(textInput));\n    this.container.appendChild(this.wrapField(sizeInput));\n    this.container.appendChild(this.wrapField(weightInput));\n    this.container.appendChild(this.wrapField(alignInput));\n    this.container.appendChild(this.wrapField(textcolorInput));\n    this.container.appendChild(this.wrapField(applyButton));\n    this.container.appendChild(this.paragraph);\n  }\n  // Wrap each input in a div to ensure vertical stacking\n  wrapField(field) {\n    var wrapper = document.createElement(\"div\");\n    wrapper.style.marginBottom = \"0.5rem\";\n    wrapper.appendChild(field);\n    return wrapper;\n  }\n  // Create a generic text input\n  createTextInput(placeholder, onChange) {\n    var input = document.createElement(\"input\");\n    input.type = \"text\";\n    input.placeholder = placeholder;\n    input.style.width = \"100%\";\n    input.oninput = () => onChange(input.value.trim());\n    return input;\n  }\n  // Create a number input for font size\n  createNumberInput(placeholder, onChange) {\n    var input = document.createElement(\"input\");\n    input.type = \"number\";\n    input.placeholder = placeholder;\n    input.style.width = \"100px\";\n    input.oninput = () => onChange(input.value.trim());\n    return input;\n  }\n  // Create a dropdown for provider selection\n  createSelect(options, onChange) {\n    var select = document.createElement(\"select\");\n    options.forEach(opt => {\n      var option = document.createElement(\"option\");\n      option.value = opt;\n      option.textContent = opt;\n      select.appendChild(option);\n    });\n    select.onchange = () => onChange(select.value);\n    return select;\n  }\n  // Validate inputs before enabling the Apply button\n  validate(button) {\n    var validFont = this.state.fontFamily.length > 0;\n    var validSize = this.state.fontSize > 0;\n    button.disabled = !(validFont && validSize);\n  }\n  // Inject font and apply styles to the paragraph\n  renderFont() {\n    var config = {\n      name: this.state.fontFamily,\n      source: this.state.provider.toLowerCase(),\n      weights: [this.state.fontWeight],\n      cdnUrl: this.state.provider === \"CDN\" ? this.state.cdnUrl : undefined,\n      fontWeight: this.state.fontWeight\n    };\n    (0,_Shared_font_loader__WEBPACK_IMPORTED_MODULE_0__.loadFont)(config); // ✅ Use shared module\n    // Apply font and size to paragraph\n    this.paragraph.style.fontFamily = \"\\\"\".concat(this.state.fontFamily, \"\\\", sans-serif\");\n    this.paragraph.style.fontSize = \"\".concat(this.state.fontSize, \"px\");\n    this.paragraph.style.fontWeight = this.state.fontWeight;\n    this.paragraph.style.textAlign = this.state.textAlign;\n    this.paragraph.style.color = this.state.textcolor;\n    this.paragraph.textContent = this.state.exampleText;\n  }\n  updateView(context) {\n    // No dynamic updates needed for this demo\n  }\n  getOutputs() {\n    return {};\n  }\n  destroy() {\n    // Clean up if needed\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./FontDemoControl/index.ts?\n}");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./FontDemoControl/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('FontDemo.FontDemoControl', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.FontDemoControl);
} else {
	var FontDemo = FontDemo || {};
	FontDemo.FontDemoControl = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.FontDemoControl;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}