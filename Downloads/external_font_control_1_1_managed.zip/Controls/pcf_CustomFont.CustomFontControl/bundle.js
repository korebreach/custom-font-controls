/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "../Shared/font-loader.ts":
/*!********************************!*\
  !*** ../Shared/font-loader.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   loadFont: () => (/* binding */ loadFont)\n/* harmony export */ });\nfunction loadFont(config) {\n  switch (config.source) {\n    case \"google\":\n      injectGoogleFont(config.name, config.weights);\n      break;\n    case \"cdn\":\n      if (!config.cdnUrl) {\n        console.warn(\"Missing CDN URL for font: \".concat(config.name));\n        return;\n      }\n      injectCDNFont(config.name, config.cdnUrl, config.fontWeight);\n      break;\n    default:\n      console.warn(\"Unsupported font source: \".concat(config.source));\n  }\n}\nfunction injectGoogleFont(name, weights) {\n  var formattedName = name.replace(/ /g, \"+\");\n  var weightParam = (weights === null || weights === void 0 ? void 0 : weights.length) ? \":wght@\".concat(weights.join(\";\")) : \"\";\n  var href = \"https://fonts.googleapis.com/css2?family=\".concat(formattedName).concat(weightParam, \"&display=swap\");\n  injectStylesheet(href);\n}\nfunction injectCDNFont(name, cdnUrl) {\n  var fontWeight = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : \"normal\";\n  var fontFace = \"\\n    @font-face {\\n      font-family: '\".concat(name, \"';\\n      src: url('\").concat(cdnUrl, \"') format('woff2');\\n      font-weight: \").concat(fontWeight, \";\\n      font-style: normal;\\n    }\\n  \");\n  injectStyleBlock(fontFace);\n}\nfunction injectStylesheet(href) {\n  var link = document.createElement(\"link\");\n  link.rel = \"stylesheet\";\n  link.href = href;\n  document.head.appendChild(link);\n}\nfunction injectStyleBlock(css) {\n  var style = document.createElement(\"style\");\n  style.textContent = css;\n  document.head.appendChild(style);\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/../Shared/font-loader.ts?\n}");

/***/ }),

/***/ "./custom_font/index.ts":
/*!******************************!*\
  !*** ./custom_font/index.ts ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   CustomFontControl: () => (/* binding */ CustomFontControl)\n/* harmony export */ });\n/* harmony import */ var _Shared_font_loader__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../Shared/font-loader */ \"../Shared/font-loader.ts\");\n\nclass CustomFontControl {\n  constructor() {\n    this.currentFontFamily = \"\";\n  }\n  init(context, notifyOutputChanged, state, container) {\n    this.notifyOutputChanged = notifyOutputChanged;\n    this.container = container;\n    // Create and style the text element\n    this.textElement = document.createElement(\"p\");\n    this.textElement.style.margin = \"0\";\n    this.textElement.style.padding = \"0\";\n    this.container.appendChild(this.textElement);\n    this.updateView(context);\n  }\n  updateView(context) {\n    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s;\n    var text = (_b = (_a = context.parameters.Text) === null || _a === void 0 ? void 0 : _a.raw) !== null && _b !== void 0 ? _b : \"Sample text\";\n    var fontFamily = (_d = (_c = context.parameters.FontFamily) === null || _c === void 0 ? void 0 : _c.raw) !== null && _d !== void 0 ? _d : \"Roboto\";\n    var fontProvider = (_g = (_f = (_e = context.parameters.FontProvider) === null || _e === void 0 ? void 0 : _e.raw) === null || _f === void 0 ? void 0 : _f.toLowerCase()) !== null && _g !== void 0 ? _g : \"google\";\n    var cdnUrl = (_j = (_h = context.parameters.CDNUrl) === null || _h === void 0 ? void 0 : _h.raw) !== null && _j !== void 0 ? _j : \"\";\n    var fontSize = (_l = (_k = context.parameters.FontSize) === null || _k === void 0 ? void 0 : _k.raw) !== null && _l !== void 0 ? _l : 16;\n    var fontWeight = (_o = (_m = context.parameters.FontWeight) === null || _m === void 0 ? void 0 : _m.raw) !== null && _o !== void 0 ? _o : \"400\";\n    var textAlign = (_q = (_p = context.parameters.TextAlign) === null || _p === void 0 ? void 0 : _p.raw) !== null && _q !== void 0 ? _q : \"left\";\n    var textColor = (_s = (_r = context.parameters.TextColor) === null || _r === void 0 ? void 0 : _r.raw) !== null && _s !== void 0 ? _s : \"#000000\";\n    // Load font only if fontFamily changes\n    if (fontFamily !== this.currentFontFamily) {\n      var config = {\n        name: fontFamily,\n        source: fontProvider,\n        cdnUrl,\n        weights: [fontWeight],\n        fontWeight\n      };\n      (0,_Shared_font_loader__WEBPACK_IMPORTED_MODULE_0__.loadFont)(config);\n      this.currentFontFamily = fontFamily;\n    }\n    // Apply styles and content\n    this.textElement.textContent = text;\n    this.textElement.style.fontFamily = \"\\\"\".concat(fontFamily, \"\\\", sans-serif\");\n    this.textElement.style.fontSize = \"\".concat(fontSize, \"px\");\n    this.textElement.style.fontWeight = fontWeight;\n    this.textElement.style.textAlign = textAlign;\n    this.textElement.style.color = textColor;\n  }\n  getOutputs() {\n    return {};\n  }\n  destroy() {\n    this.container.innerHTML = \"\";\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./custom_font/index.ts?\n}");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./custom_font/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('CustomFont.CustomFontControl', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.CustomFontControl);
} else {
	var CustomFont = CustomFont || {};
	CustomFont.CustomFontControl = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.CustomFontControl;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}